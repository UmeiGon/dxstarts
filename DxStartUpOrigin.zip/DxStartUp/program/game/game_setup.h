#ifndef GAME_SETUP_H
#define GAME_SETUP_H



void game_setup() ;




#endif