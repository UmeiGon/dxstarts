#ifndef DEBUG_TRACE_H
#define DEBUG_TRACE_H


void DebugTrace( char *_str, ... ) ;

void DrawStringEx(int x, int y, int color, char *_str, ...) ;

#endif