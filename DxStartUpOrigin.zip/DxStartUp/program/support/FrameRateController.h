#ifndef FPS_CONTROLLER_H
#define FPS_CONTROLLER_H

float GetFps() ;
void FpsControll() ;
void FpsSetting( float RefreshRate, int UpdateTime ) ;

#endif
