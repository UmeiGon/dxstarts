
#ifndef IS_KEY_DOWN_TRIGGER_H
#define IS_KEY_DOWN_TRIGGER_H

void KeyTriggerInitialize() ;
bool IsKeyDownTrigger( unsigned char _key ) ;

#endif